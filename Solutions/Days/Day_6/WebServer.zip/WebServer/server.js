const express=require('express');
const bodyParser=require('body-parser');    
const fs=require('fs');
const app=express();

//middleware configuration
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
//configure static middleware for getting html css, javascript as static web resource
app.use(express.static('public'));
//HTTP Request Handling mapping
app.get("/",(req, res)=>{
    res.sendFile("index.html")
});

app.get("/api/hello",(req, res)=>{
    let person={"fullname":"Sachin Tendulkar",
                 "location": "Mumbai"};
    res.send(person);
});

app.post("/api/login",(req, res)=>{
    let url=req.url;
    let userData=req.body;
    let fileName="credentials.json";
    fs.readFile(fileName,(err,data)=>{
        let staticFolderPath='D:\\RaviT\\softobiz\\BootCamp_2\\Day_6\\WebServer\\public';
        let streCredentials=data.toString();
        let credentials=JSON.parse(streCredentials);
        let userFound=credentials.find((user)=>(user.email === userData.email && user.password===userData.password))
        if(userFound){
            res.sendFile("welcome.html",{ root:staticFolderPath });
        }
        else{
            res.sendFile("welcome.html", { root: staticFolderPath});
        }
    })
})

app.post("/api/register",
            (req, res)=>{
                //get data from body
                let userData=req.body;
                //read all crednetials from file
                // parse into  json array
                let fileName="credentials.json";
                fs.readFile(fileName,(err,data)=>{
                    let strCredentials=data.toString();
                    let credentials=JSON.parse(strCredentials);
                    //push data received from body  into json array
                    credentials.push(userData);
                    //write complete json array into file
                    strCredentials=JSON.stringify(credentials);
                    fs.writeFile(fileName,strCredentials,
                        ()=>{
                                console.log("new user registered into credentials");
                                res.send("new user registered into credentials");
                        });
                });       
        });

//set server in listen mode

app.listen(7000,()=>{

    console.log("express web server is listening on port 7000");
});