

exports.getPersonDetails=()=>{
    let person={
        name:'Mangesh',
        fullname:'Mangesh Shitaram Kesari',
        email:'mangesh.kesari@transflower.in',
        contactnumber:'9881735654'
    };
    return person;
}