//Data Persistance using MongoDB database (NoSQL)

export default class MongoDBManager{
    constructor(){    }
    
    getAll=()=>{
         
    };
    
    getById=(id)=>{ 
        
    };
    
    remove=(id)=>{
        
    }
    
    insert=(person)=>{
        
    }
    
    update=(productTobeUpdated)=>{
       
    }
}
