//Data Persistance using mySQL Database
const mysql=require('mysql');

export default class MySQLDBManager{
    constructor(){    }
    
    getAll=()=>{
         
    };
    
    getById=(id)=>{ 
        
    };
    
    remove=(id)=>{
        
    }
    
    insert=(person)=>{
        
    }
    
    update=(productTobeUpdated)=>{
       
    }
}